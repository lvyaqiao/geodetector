from ._load_data import load_disease
